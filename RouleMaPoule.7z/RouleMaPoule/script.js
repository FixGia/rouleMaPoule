function openMenu() {
  var logoMenu = document.querySelector("#logoMenu");
  logoMenu.classList.toggle("opened");
}
